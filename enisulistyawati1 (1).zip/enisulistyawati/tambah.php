<?php
session_start();
include "koneksi.php";
cekSession();
cekCookies();
levelAdmin();
?>

<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Formulir Tambah</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        <script src="javascript.js"></script>
    </head>
    <body>
        <!-- DAFTAR MENU -->
        <?php include "menu.php" ?>

        <div class="container">
            <!-- Content here -->
            <br>
            <h3 class="text-center">Formulir Halaman Admin</h3>
            <br>
            <form action="proses.php" enctype="multiple/form-data">
                <div class="mb-3 row">
                    <label for="nama" class="col-sm-2 col-form-label">Nama Mahasiswa</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="nama" name="nama" required>
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="foto" class="col-sm-2 col-form-label">Foto Mahasiswa</label>
                    <div class="col-sm-10">
                        <img src="img/default.jpeg" alt="" height="150px" id="preview">
                        <input type="file" class="form-control" id="foto" name="foto" accept=".jpg, .jpeg, .png" onchange="fileValidation()">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="email" class="col-sm-2 col-form-label">Email Mahasiswa</label>
                    <div class="col-sm-10">
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="tgl_lahir" class="col-sm-2 col-form-label">Tanggal Lahir</label>
                    <div class="col-sm-10">
                        <input type="date" class="form-control" id="tgl_lahir" name="tgl_lahir" required>
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="" class="col-sm-2 col-form-label">Jenis Kelamin</label>
                    <div class="col-sm-10">
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="jenis_kelamin" id="L" value="L" required>
                        <label class="form-check-label" for="L">
                            Laki-laki
                        </label>
                        </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="jenis_kelamin" id="P" value="P">
                        <label class="form-check-label" for="P">
                            Perempuan
                        </label>
                        </div>
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="prodi" class="col-sm-2 col-form-label">Program Studi</label>
                    <div class="col-sm-10">
                    <select class="form-select" aria-label="Default select example" id="prodi" name="prodi" required>
                        <option value="">~ Pilih Program Studi ~</option>
                        <option value="SK">Sistem Komputer</option>
                        <option value="SI">Sistem Informasi</option>
                        <option value="TI">Tekknologi Informasi</option>
                        <option value="MI">Manajemen Informatika</option>
                        <option value="BD">Bisnis Digital</option>
                    </select>
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="" class="col-sm-2 col-form-label">Minat</label>
                    <div class="col-sm-10">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="minat[]" value="game" id="game">
                        <label class="form-check-label" for="game">
                            Game
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="minat[]" value="programing" id="programing">
                            <label class="form-check-label" for="programing">
                            Programing
                        </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="minat[]" value="multimedia" id="multimedia">
                            <label class="form-check-label" for="multimedia">
                            Multimedia
                        </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" name="minat[]" value="videographer" id="videographer">
                            <label class="form-check-label" for="videographer">
                            Videographer
                        </label>
                        </div>
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="" class="col-sm-2 col-form-label"></label>
                    <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary">Kirim</button>
                    <button type="reset" class="btn btn-secondary">Reset</button>
                    </div>
                </div>
            </form>
        </div>


        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    </body>
</html>