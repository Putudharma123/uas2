<?php
include "koneksi.php";

$kode_prodi      = $_POST['kode_prodi'];
$nama_prodi    = $_POST['nama_prodi'];

$query  = "INSERT INTO tb_prodi (kode_prodi, nama_prodi)
    VALUES ('$kode_prodi', '$nama_prodi')";
mysqli_query($koneksi, $query);

header("location: prodi.php")
?>

