<?php
session_start();
include "koneksi.php";
cekSession();
cekCookies();

$nama          = $_POST['nama'];
$email         = $_POST['email'];
$tgl_lahir     = $_POST['tgl_lahir'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$prodi         = $_POST['prodi'];
$minat         = implode(",", $_POST['minat']);

$query = "INSERT INTO tb_mhs (nama_mhs, email, tgl_lahir, jenis_kelamin, prodi, minat)
            VALUES ('$nama', '$email', '$tgl_lahir', '$jenis_kelamin', '$prodi', '$minat' )";
mysqli_query($koneksi, $query);

header("location: mhs.php");
?>