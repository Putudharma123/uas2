<?php
session_start();
include "koneksi.php";
cekSession();
cekCookies();

$id            = $_POST['id'];
$nama          = $_POST['nama'];
$email         = $_POST['email'];
$tgl_lahir     = $_POST['tgl_lahir'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$prodi         = $_POST['prodi'];
$minat         = implode(",", $_POST['minat']);

$query = "UPDATE tb_mhs
            SET nama_mhs = '$nama',
                email = '$email',
                tgl_lahir = '$tgl_lahir',
                jenis_kelamin = '$jenis_kelamin',
                prodi = '$prodi',
                minat = '$minat'
            WHERE id_mhs = '$id'";
mysqli_query($koneksi, $query);

header("location: mhs.php");
?>