<?php
session_start();
include "koneksi.php";
cekSession();
cekCookies();
levelAdmin();

$id = $_GET['id'];

$query = "DELETE FROM tb_prodi WHERE id_prodi = '$id'";
mysqli_query($koneksi, $query);

header("location: prodi.php");
?>