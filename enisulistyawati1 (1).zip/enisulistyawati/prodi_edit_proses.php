<?php
session_start();
include "koneksi.php";
cekSession();
cekCookies();
levelAdmin();

$id				= $_POST['id'];
$nama_prodi  	= $_POST['nama_prodi'];
$kode_prodi     = $_POST['kode_prodi'];

$query = "UPDATE tb_prodi
			SET kode_prodi = '$kode_prodi',
                nama_prodi = '$nama_prodi'

			WHERE id_prodi = '$id'";
mysqli_query($koneksi, $query);
header("location: prodi.php");
?>