<?php
session_start();
include "koneksi.php";
cekSession();
cekCookies();

$id = $_GET['id'];

$query = "DELETE FROM tb_mhs WHERE id_mhs = '$id'";
mysqli_query($koneksi, $query);

header("location: mhs.php");
?>