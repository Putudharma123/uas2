<?php
session_start();
include "koneksi.php";
cekSession();
cekCookies();
?>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Formulir Edit Dokumen</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        <script src="javascript.js"></script>
    </head>
    <body>
        <!-- DAFTAR MENU -->
        <?php include "menu.php" ?>
        <!-- DAFTAR MENU -->
        
        
        <!-- DAFTAR MENU -->

        <div class="container">
            <!-- Content here -->
            <br>
            <h3 class="text-center">Formulir Edit Upload Dokumen</h3>
            <br>
            <?php
            $id = $_GET['id'];
            $query = "SELECT * FROM tb_upload WHERE id_upload = '$id'";
            $data = mysqli_query($koneksi, $query);
            $row = mysqli_fetch_assoc($data);
            ?>
            <form id="uploadForm" action="upload_edit_proses.php" method="post" enctype="multipart/form-data">
                <div class="mb-3 row">
                    <label for="judul" class="col-sm-2 col-form-label">Judul Dokumen</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="judul" value="<?= $row['judul_dokumen'] ?>" name="judul" required>
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="keterangan" class="col-sm-2 col-form-label">Keterangan</label>
                    <div class="col-sm-10">
                        <textarea class="form-control" id="keterangan" name="keterangan" rows="3"><?= $row['keterangan'] ?></textarea>
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="file" class="col-sm-2 col-form-label">Upload Dokumen</label>
                    <div class="col-sm-10">
                        <a href="upload/<?= $row['nama_file'] ?>" target="_blank">
                            <?= $row['judul_dokumen'] ?></a>
                        <input type="file" class="form-control" id="file" name="file" accept=".pdf, .docx">
                    </div>
                </div>
                <div class="mb-3 row">
                    <label for="" class="col-sm-2 col-form-label"></label>
                    <div class="col-sm-10">
                        <input type="hidden" name="id" value="<?= $id ?>">
                        <button type="submit" class="btn btn-primary">Kirim</button>
                        <button type="reset" class="btn btn-secondary">Reset</button>
                    </div>
                </div>
            </form>
        </div>

        <script>
            document.getElementById('uploadForm').addEventListener('submit', function(event) {
                var input = document.getElementById('file');
                if (input.files.length > 0) {
                    var fileSize = input.files[0].size; // Ukuran file dalam byte
                    // Batasan ukuran file (dalam byte)
                    var maxSize = 5 * 1024 * 1024; // Contoh: Batasan 5MB
                    if (fileSize > maxSize) {
                        event.preventDefault(); // Menghentikan pengiriman form
                        alert('Ukuran file terlalu besar! Maksimum 5MB');
                    }
                }
            });
        </script>

        <!-- JAVASCRIPT -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    </body>
</html>