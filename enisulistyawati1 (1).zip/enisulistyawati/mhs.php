<?php
session_start();
include "koneksi.php";
cekSession();
cekCookies();
?>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Data Mahasiswa</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" 
        crossorigin="anonymous">
        <!-- DATATABLES -->
        <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
        <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
        <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js"></script>
        <script>
            $(document).ready(function() {
                $('#example').DataTable( {
                    dom: 'Bfrtip',
                    buttons: [
                        'copy', 'csv', 'excel', 'pdf', 'print'
                    ]
                } );
            } );
        </script>
        <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css">
        <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.dataTables.min.css">
        <!-- DATATABLES -->
    </head>
    <body>
        <!-- DAFTAR MENU -->
        <?php include "menu.php" ?>
        <!-- DAFTAR MENU -->

        <div class="container">
            <!-- Content here -->
            <br>
            <h3 class="text-center">Halaman Data Mahasiswa</h3>
            <br>
            <a href="mhs_tambah.php" class="btn btn-primary">Tambah</a> <br><br>
            <table id="example" class="display nowrap" style="width:100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Tgl Lahir</th>
                <th>Jenis</th>
                <th>prodi</th>
                <th>minat</th>
                <th>#</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $no = 1;
            $query = "SELECT * FROM tb_mhs";
            $data = mysqli_query($koneksi, $query);
            while ($row = mysqli_fetch_assoc($data)) {
            ?>
            <tr>
                <td><?php echo $no++ ?></td>
                <td><?php echo $row['nama_mhs']?></td>
                <td><?= $row['email'] ?></td>
                <td><?= date("d M Y", strtotime($row['tgl_lahir'])) ?></td>
                <td>
                        <?php 
                            if($row['jenis_kelamin'] == "L") {
                                echo "Laki-laki";
                            } else {
                                echo "Perempuan";
                            }
                        ?>
                    </td>
                    <td>
                        <?php 
                            if ($row['prodi'] == "1") {
                                echo "Sistem Komputer";
                            } elseif ($row['prodi'] == "2") {
                                echo "Manajemen Informatika";
                            } elseif ($row['prodi'] == "3") {
                                echo "Sistem Informasi";
                            } elseif ($row['prodi'] == "4") {
                                echo "Teknologi Informasi";
                            } elseif ($row['prodi'] == "5") {
                                echo "Bisnis Digital";
                            }
                        ?>
                    </td>
                    <td><?= $row['minat'] ?></td>
                    <td>
                        <a href="mhs_edit.php?id=<?= $row[ 'id_mhs'] ?>" class="btn btn-success btn-sm">Edit</a>
                        <a href="mhs_hapus.php?id=<?= $row[ 'id_mhs'] ?>"onclick="return confirm('Yakin ingin menghapus data ini')" class="btn btn-danger btn-sm">Hapus</a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
        <tfoot>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Tgl Lahir</th>
                <th>Jenis</th>
                <th>prodi</th>
                <th>minat</th>
                <th>#</th>
            </tr>
        </tfoot>
    </table>
        </div>

        <!-- JAVASCRIPT -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    </body>
</html>