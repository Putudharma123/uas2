<?php
session_start();
include "koneksi.php";

$email     = $_POST['email'];
$password  = md5($_POST['password']);

$query = "SELECT * FROM tb_admin WHERE email = '$email' AND password = '$password'";
$data = mysqli_query($koneksi, $query);
$row = mysqli_fetch_assoc($data);

//hitung data yg ditemukan. kalo ketemu $count 1, kalo ngga $count 0
$count = mysqli_num_rows($data);

if($count == 0) {
    header("location:index.php?pesan=notfound");
} else {
    //buatkan session
    $_SESSION = array(
        'id_admin'  => $row['id_admin'],
        'email'     => $row['email'],
        'level'     => $row['level']
    );

    //buat cookies
    $expired = time() + 60 * 60;
    setcookie("id_admin", $row['id_admin'], $expired, "/");

    header("location:beranda.php");
}
?>