<nav class="navbar navbar-expand-lg bg-nabar" style="background-color: #daeaf6;">
<div class="container-fluid">
        <a class="navbar-brand" href="#">ITB STIKOM BALI</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="beranda.php">Beranda</a>
                </li>
                <?php if($_SESSION['level'] == 0) { ?>
                    <li class="nav-item">
                        <a class="nav-link" href="admin.php">Admin</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="prodi.php">Program Studi</a>
                    </li>
                <?php }  ?>
                <li class="nav-item">
                    <a class="nav-link" href="mhs.php">Mahasiswa</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="upload.php">Upload File</a>
                </li>
            </ul>
            <div class="d-flex" role="search">
                <a onclick="return confirm('Apakah Anda Yakin Ingin Logout?')" class="btn btn-danger" href="logout.php">Logout</a>
            </div>
        </div>
    </div>
</nav>