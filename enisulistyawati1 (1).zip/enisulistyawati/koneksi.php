<?php
$koneksi = mysqli_connect("localhost", "root", "", "db_aa225");

if (mysqli_connect_errno()) {
    echo "Koneksi database gagal : " . mysqli_connect_error();
}

function cekSession() {
    if(!isset($_SESSION['id_admin'])) {
        header("location:index.php?pesan=login");
    }
}

function cekCookies() {
    if(!isset($_COOKIE['id_admin'])) {
        header("location:index.php?pesan=login");
    }
}

function levelAdmin() {
    if($_SESSION['level'] !=0) {
        header("location:beranda.php?pesan=terbatas");
    }
}
?>